<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
?>
<style>
	.main{
		
		
	}
	.main h1{
		font-family: "Times New Roman", Georgia, Serif;
		font-size: 30px;
		color:#5e0c17;
	}
	.adminpanel {
    width: 772px;
    color: #d720a7;
    margin: 104px auto 0;
    padding: 28px;
    border: 2px solid #ddd;
    font-family: "Times New Roman", Georgia, Serif;
    font-size: 48px;
}
</style>
<div class="main">
<h1>Admin Panel</h1>
	<div class = "adminpanel">
		<i><h2>Welcome to Admin Panel</h2></i>
		
	</div>
</div> 
<?php include 'inc/footer.php'; ?>