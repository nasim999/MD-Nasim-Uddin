<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/loginheader.php');
	include_once ($filepath.'/../classes/Admin.php');
	$ad = new Admin();
?>
<?php 
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$adminData = $ad->getAdminData($_POST);
	}
?>
<style>
.main h1{
	font-family: "Times New Roman", Georgia, Serif;
		font-size: 35px;
		color:#5e0c17;
}
.adminlogin{
	font-family: "Times New Roman", Georgia, Serif;
		font-size: 20px;
		color:#040303;
}
.a1 {
    background: #fff none repeat scroll 0 0;
    border-radius: 19px;
    box-sizing: border-box;
    height: 247px;
    left: 48%;
    margin-top: 50px;
    overflow: hidden;
    padding: 40px;
    position: absolute;
    transform: translateX(-50%) translateY(-50%);
    width: 460px;
}
.a2{
	position: absolute;
	left: 0;
	top: 0;
	width: 100%;
	height: 100%;
	background: #3b5998;
	z-index: 2;
	transition: width 0.2s ease-in-out;
}
.a1:hover .a2, .a1.focused > .a2{
	width: 30px;
}
.a1:hover .a2>.text, .a1.focused > .a2 > .text{
	font-size: 1rem;
	transform: rotate(-90deg);
}

.a2 > .text {
    font-size: 4rem;
    font-family: sans-serif,Arial;
    color: #fff;
    text-align: center;
    display: block;
    line-height: 195px;
    transition: all 0.9s ease-in-out;
}
.a1>form{
	width: 200px;
	margin: 0 auto;
}
.a1>form>.input{
	width: 100%;
	height: 50px;
	outline: none;
	border: 0px;
	font-size: 20px;
	font-family: sans-serif,Arial;
	border-bottom: 2px solid #3b5998;
	color: #3b5998;
}
</style>
<div class="main">
<h1>Admin Login</h1>
<div class="adminlogin">
	<div class="a1">
		 	<div class="a2">
<span class="text">LOGIN</span>
</div>
	<form action="" method="post">
		<table>
			<tr> 
				<td>Username</td>
				<td><input type="text" name="adminUser" required/></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="adminPass" required/></td>
			</tr>
			<tr>
				<td></td>
				<td style="text-align: center;font-size: 25px;"><input type="submit" name="login" value="Login Now"/></td>
			</tr>
			<tr>
				<td colspan="2">
				<?php
				if(isset($adminData)){
					echo $adminData;
				}
				?>
				</td>
			</tr>
		</table>
	</from>
</div>
</div>
</div>username:nasim password:123456
<?php include 'inc/footer.php'; ?>