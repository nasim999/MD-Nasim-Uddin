<?php include 'inc/header.php'; ?>
<?php 
	Session::checkSession();
	 
?>
<style>
	.starttest a{
		font-family: "Times New Roman", Georgia, Serif;
		font-size: 25px;
		color:#121069;
	}
</style>
<div class="main">
<h1>Congratulations ! You are Done    !</h1>
	<div class="starttest">
	<p>You have just Completed .</p>
	<p>Final Sore : 
		<?php
			if(isset($_SESSION['score'])){
				echo $_SESSION['score'];
				unset($_SESSION['score']);

			}
		
		?>
		
	</p>
	<a href="viewans.php"><h2>See Correct Answer</h2></a>
	<a href="starttest.php"><h2>Again Start Exam!!!!</h2></a>
	</div>
  </div>
<?php include 'inc/footer.php'; ?>