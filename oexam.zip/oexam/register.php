<div class="a4"><?php
	include 'inc/header.php';
?>
<style>
.segment img{
 height: 150px;
margin-left: 6px;
padding-top: 20px;
width: 350px;
}
</style>
<div class="main">
<h1>Online Exam System - User Registration</h1>
	<div class="segment" style="margin-right:30px;">
		<img src="img/regi.png"/>
	</div>
	<div class="segment">
     <div class="a1">
      <div class="a2">
<span class="text">Register</span>
</div>
	<form action="" method="post">
		<table>
		<tr>
           <td>Name  :</td>
           <td><input type="text" name="name" id = "name" placeholder=" Name"></td>
         </tr>
		<tr>
           <td>Username:</td>
           <td><input name="username" type="text" id="username" placeholder="User Name"></td>
         </tr>
         <tr>
           <td>Password:</td>
           <td><input type="password" name="password" id = "password" placeholder="User Password"></td>
         </tr>
         
         <tr>
           <td>E-mail:</td>
           <td><input name="email" type="text" id = "email" placeholder="User Email ID"></td>
         </tr>
         <tr>
           <td></td>
           <td style="text-align: center;font-size: 25px;"><input type="submit" id="regsubmit" value="Sign Up "></td>
         </tr>
       </table>
	   </form>
   </div>
   <div class="newuser">
	   <p>If You Have Already Registered !!<br>Please <a href="index.php">Login</a> Here</p>
	   <span id = "state"></span></div>
	</div>
</div>
</div>
<?php include 'inc/footer.php'; ?>