 <?php  include 'inc/header.php';
  ?>
  <style type="text/css">
  .page{
  width: 780px;
  margin: auto;
  font-size: 16px;
  font-family:sans-serif;

}
.infophoto{
  height: 250px;
  top: auto;
  border-radius: 50%
}
.info{
  float: left;
}
.photo{
  float: right;
  height: ;
  width: ;
  border-radius: 50%
}
.selection{
  margin-bottom:;
}
.sec-1{
  float: ;
}
.sec-2{
  margin-left: px;
}
strong{
  font-size: 26px;
}
.selection{
  margin-bottom: px;
  text-align: justify;
}
h2{
  font-size: 28px;
  color: #4c08a0;
  }
  body{
    background-color: #f3fa86;
    position: relative;
    border:0;
    
  }
  </style>
 <div class="page">
      <div class="infophoto">
        <div class="info">
        <h1>About</h1>
        <p><strong>MD Nasim Uddin</strong><br>
        Sadar, Dinajpur</br>
        Email: uddinmdnasim4@gmail.com</br>
        Contact Number: 01768759401</p></p>
       </div>
        <div class="photo">
          <img src="img/nasim.jpg" width="230" height="250" />
        </div>
      </div>
      <div class="section">
        <div class="sec-1">
        </div>
        <div class="sec-2">
        </div>
      </div>
      <div class="section">
        <h2>Key Skills</h2>

        <div class="sec-1">
          <ul>
            <li>MS Office(70%)</li>
            <li>Internet Browsing</li>
            <li>HTML,css,javascript,php,pdo,laravel
           </li>
           <li>Fluent writing,speaking skill in Bangla</li>
           <li>Moderate writing,speaking skill inEnglish</li>
          </ul>
        </div>
        <div class="sec-2">
        </div>
      </div>
      <div class="sectionContent">
        <div class="1">
  				<article>
  					<h2>Education</h2>
            <p><strong>Hajee Mohammad Danesh Science & Tecnology University</strong>
  					<p>I am now studying BSc in Fisheries there  . </p>
             <p><strong>Dinajpur Govt. College</strong>
            <p>I have completed my HSC in Science there  . </p>
  				</article>
        </div>
        <div class="sec-2">

        </div>
  			</div>
    </div>