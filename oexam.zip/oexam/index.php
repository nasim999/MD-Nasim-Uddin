<div class="a3"><?php include 'inc/header.php'; ?>
<?php
	Session::checkLogin();
?>
<style type="text/css">


</style>
<div class="main">
	

<h1>Online Exam System(User Log In)</h1>
    

	<div class="segment" style="margin-right:30px;">

		
	</div>
	
		 <div class="a1">
		 	<div class="a2">
<span class="text">LOGIN</span>
</div>
    

	<form action="" method="post">

		<table class="tbl">    
			 <tr>
			   <td>Email</td>
			   <td><input name="email" type="text" id = "email" placeholder="User Email ID"></td>
			 </tr>
			 <tr>
			   <td>Password </td>
			   <td><input name="password" type="password" id = "password" placeholder="User Password"></td>
			 </tr>
			 
			  <tr>
			  <td></td>
			   <td><input type="submit" id="loginsubmit" value="Log In">
			   </td>
			 </tr>
       </table>
	   </form></div>
	   <div class="newuser">
	  <p> If You Are A New User !!!!<br>Please <a href="register.php">Register</a> Here</p>
		<span class="empty" style ="display:none">Field Must Not be Empty !</span>
		<span class="error" style ="display:none">Emal or Password not Matched !</span>
		<span class="disable" style ="display:none">User ID Disable !</span>
		email:md@gmail.com password:123456</div>
		
</div>
</div>
<?php include 'inc/footer.php'; ?>