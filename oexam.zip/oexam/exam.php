<div class="b5"><?php include 'inc/header.php'; ?>
<?php 
	Session::checkSession();
?>
<div class="main">
<h1>Welcome to Online Exam </h1>
	<div class="segment" style="margin-right:30px;">
		<img src="img/online_exam.png"/>
	</div>
	<div class="segment">
	
	<ul>
		<li><a href="starttest.php"><h2>Start Now...</h2></a></li>

	</ul>
	</div>
	
  </div></div>
<?php include 'inc/footer.php'; ?>